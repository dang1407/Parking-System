﻿
namespace WebAPI.Application
{
    public interface ITitleService : IBaseCompanyService<TitleDTO, TitleCreatedDTO, TitleUpdateDTO>
    {
    }
}
