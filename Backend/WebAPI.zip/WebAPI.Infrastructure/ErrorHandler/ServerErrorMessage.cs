﻿namespace WebAPI
{
    public class ServerErrorMessage
    {
        public static string ServerUnknownError = "Có lỗi xảy ra, vui lòng liên hệ chúng tôi để được hỗ trợ";
    }
}
