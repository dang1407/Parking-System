<template>
  <div>Đây là Home Page</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
