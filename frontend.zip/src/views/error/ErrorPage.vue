<template>
  <div>Có lỗi xảy ra</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
