  if (dateDB && dateDB !== "") {
