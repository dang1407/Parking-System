export const genderLanguage = {
  vi: {
    0: "Nữ",
    1: "Nam",
    2: "Khác",
  },
  en: {
    0: "Female",
    1: "Male",
    2: "Other",
  },
};
