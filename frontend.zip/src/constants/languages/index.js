export const languageDictionary = [
  {
    label: "Tiếng Việt",
    code: "vi",
    languageLabel: "Ngôn ngữ",
  },
  {
    label: "English",
    code: "en",
    languageLabel: "Language",
  },
];
