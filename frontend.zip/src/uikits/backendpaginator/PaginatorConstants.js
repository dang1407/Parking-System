export const PaginatorConstants = {
  vi: {
    total: "Tổng",
    numberRecords: "số bản ghi",
    numberRecordsPerPage: "Số bản ghi/trang",
    recordsPerPage: "Số bản ghi/trang",
  },
  en: {
    total: "Total",
    numberRecords: "number of records",
    numberRecordsPerPage: "Records/page",
  },
};
