export const Role = {
  ParkMember: "parkmember",
  Employee: "employee",
  Admin: "admin",
};
